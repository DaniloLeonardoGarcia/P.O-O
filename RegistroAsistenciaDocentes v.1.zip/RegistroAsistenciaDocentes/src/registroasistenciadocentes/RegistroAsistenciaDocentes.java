package registroasistenciadocentes;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class RegistroAsistenciaDocentes {

    public static void main(String[] args) {
        GestorAsistencia gestor = new GestorAsistencia() {};
        Scanner scanner = new Scanner(System.in);

        DateTimeFormatter fmt1 = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        DateTimeFormatter fmt2 = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        DateTimeFormatter fmt3 = DateTimeFormatter.ofPattern("dd/MM/yyyy");

        int opcion;
        do {
            System.out.println("\n" + "=".repeat(50));
            System.out.println("  REGISTRO ASISTENCIA DE DOCENTES");
            System.out.println("=".repeat(50));
            System.out.println("1. Agregar docente");
            System.out.println("2. Registrar asistencia");
            System.out.println("3. Ver asistencia de un día");
            System.out.println("4. Listar docentes");
            System.out.println("5. Salir");
            System.out.print("Seleccione una opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine(); 

            switch (opcion) {
                case 1: 
                    System.out.print("Nombre: ");
                    String nombre = scanner.nextLine();
                    System.out.print("Apellido: ");
                    String apellido = scanner.nextLine();
                    System.out.print("DNI: ");
                    String dni = scanner.nextLine();
                    gestor.agregarDocente(new Docente(nombre, apellido, dni));
                    break;

                case 2: 
                    gestor.listarDocentes();
                    if (gestor.getDocentes().isEmpty()) break;

                    System.out.print("Ingrese ID del docente: ");
                    int idDocente = scanner.nextInt();
                    scanner.nextLine();

                    Docente docenteSeleccionado = null;
                    for (Docente d : gestor.getDocentes()) {
                        if (d.getId() == idDocente) {
                            docenteSeleccionado = d;
                            break;
                        }
                    }
                    if (docenteSeleccionado == null) {
                        System.out.println("Docente no encontrado");
                        break;
                    }

                    System.out.print("Fecha (yyyy-MM-dd) o (dd-MM-yyyy) o ENTER para hoy: ");
                    String fechaStr = scanner.nextLine().trim();
                    LocalDate fecha = parsearFecha(fechaStr, fmt1, fmt2, fmt3);

                    System.out.println("1. Presente  2. Ausente  3. Justificado");
                    int est = scanner.nextInt();
                    scanner.nextLine();

                    EstadoAsistencia estado = (est == 1) ? EstadoAsistencia.PRESENTE :
                                             (est == 2) ? EstadoAsistencia.AUSENTE : EstadoAsistencia.JUSTIFICADO;

                    System.out.print("Observación (opcional): ");
                    String obs = scanner.nextLine();

                    gestor.registrarAsistencia(docenteSeleccionado, fecha, estado, obs);
                    break;

                case 3: 
                    System.out.print("Fecha (yyyy-MM-dd) o (dd-MM-yyyy) o ENTER para hoy: ");
                    String f = scanner.nextLine().trim();
                    LocalDate fechaConsulta = parsearFecha(f, fmt1, fmt2, fmt3);
                    gestor.verAsistenciaDelDia(fechaConsulta);
                    break;

                case 4: 
                    gestor.listarDocentes();
                    break;

                case 5:
                    System.out.println("¡Hasta luego!");
                    break;

                default:
                    System.out.println("Opción inválida");
            }
        } while (opcion != 5);

        scanner.close();
    }

    private static LocalDate parsearFecha(String texto, DateTimeFormatter f1, 
                                          DateTimeFormatter f2, DateTimeFormatter f3) {
        if (texto == null || texto.isEmpty()) {
            return LocalDate.now();
        }

        try {
            return LocalDate.parse(texto, f1);
        } catch (Exception e) {
            try {
                return LocalDate.parse(texto, f2);
            } catch (Exception e2) {
                try {
                    return LocalDate.parse(texto, f3);
                } catch (Exception e3) {
                    System.out.println("Formato de fecha inválido. Usando fecha de hoy: " + LocalDate.now());
                    return LocalDate.now();
                }
            }
        }
    }
}