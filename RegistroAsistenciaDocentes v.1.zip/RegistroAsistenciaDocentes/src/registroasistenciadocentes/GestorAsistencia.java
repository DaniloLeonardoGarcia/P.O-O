package registroasistenciadocentes;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
public abstract class GestorAsistencia implements IGestorAsistencia {
    
    protected List<Docente> docentes = new ArrayList<>();
    protected Map<LocalDate, List<RegistroAsistencia>> registros = new HashMap<>();
    
    @Override
    public void agregarDocente(Docente docente){
        if (docente != null){
            docentes.add(docente);
            System.out.println("Docente agregado: " + docente);
        }
        
    }
    @Override
    public void registrarAsistencia(Docente docente, LocalDate fecha, EstadoAsistencia estado, String observacion){
        RegistroAsistencia registro = new RegistroAsistencia(docente, fecha, estado, observacion);
        
        registros.putIfAbsent(fecha, new ArrayList<>());
        registros.get(fecha).add(registro);
        
        System.out.println("Asistencia registrada:" + registro);
    }   
    @Override
    public void verAsistenciaDelDia(LocalDate fecha){
        List<RegistroAsistencia> lista = registros.get(fecha);
        
        System.out.println("\n=== ASISTENCIA DEL DÍA " + fecha + " ===");
        
        if (lista == null || lista.isEmpty()){
            System.out.println("No hay registro para el dia " + fecha);
            return;
        }
        lista.forEach(System.out::println);
    }
    @Override
    public void listarDocentes(){
        if (docentes.isEmpty()){
            System.out.println("No hay docentes registrados aun.");
            return;
        }
        System.out.println("\n=== LISTA DE DOCENTES ===");
        docentes.forEach(System.out::println);
    }
    @Override
    public List<Docente> getDocentes(){
        return docentes;
    }
}
