/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package registroasistenciadocentes;
import java.time.LocalDate;
import java.util.ArrayList;
public class RegistroAsistencia {
  private LocalDate fecha;
  private Docente docente;
  private EstadoAsistencia estado;
  private String observacion;       //justificacion
  
  public RegistroAsistencia(Docente docente, LocalDate fecha, EstadoAsistencia estado, String observacion) {
      this.fecha=fecha;
      this.docente=docente;
      this.estado=estado;
      this.observacion=(observacion==null)? "" : observacion;
  }
  public LocalDate getFecha() {return fecha;}
  public Docente getdocente() {return docente;}
  public EstadoAsistencia getEstado() {return estado;}
  public String getObservacion(){return observacion;}
  
  
  @Override
  public String toString(){
      return fecha + " | " + docente + " → " + estado + 
               (!observacion.isEmpty() ? " (" + observacion + ")" : "");
      }
}
