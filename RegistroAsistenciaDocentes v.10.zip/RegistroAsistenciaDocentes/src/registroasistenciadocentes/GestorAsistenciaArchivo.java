package registroasistenciadocentes;

import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class GestorAsistenciaArchivo extends GestorAsistenciaAbstracta {
    
    private final String archivoDocentes;
    private final String archivoAsistencias;
    private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    public GestorAsistenciaArchivo(String nombreBase) {
        super();
        this.archivoDocentes = nombreBase + "_docentes.csv";
        this.archivoAsistencias = nombreBase + "_asistencias.csv";
        System.out.println("Gestor de Asistencia en ARCHIVO iniciado: " + nombreBase);
        cargarDatos();
    }

    private void cargarDatos() {
        cargarDocentes();
        cargarAsistencias();
    }

    private void cargarDocentes() {
    File file = new File(archivoDocentes);
    if (!file.exists()) return;

    try (BufferedReader br = new BufferedReader(new FileReader(file))) {
        String linea;
        br.readLine(); // Saltar encabezado
        while ((linea = br.readLine()) != null) {
            if (linea.trim().isEmpty()) continue;
            String[] datos = linea.split(",");
            if (datos.length >= 4) {
                int id = Integer.parseInt(datos[0]);
                String dni = datos[3];
                
                // Validación de DNI único al cargar
                if (existeDocente(dni)) {
                    System.out.println("DNI duplicado ignorado al cargar: " + dni);
                    continue;
                }

                Docente d = new Docente(id, datos[1], datos[2], dni);
                docentes.add(d);
            }
        }
    } catch (Exception e) {
        System.out.println("Error al cargar docentes: " + e.getMessage());
    }
}

    private void cargarAsistencias() {
        File file = new File(archivoAsistencias);
        if (!file.exists()) return;

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String linea;
            br.readLine();
            while ((linea = br.readLine()) != null) {
                if (linea.trim().isEmpty()) continue;
                String[] datos = linea.split(",");
                if (datos.length >= 4) {
                    int idDocente = Integer.parseInt(datos[1]);
                    LocalDate fecha = LocalDate.parse(datos[2], formatter);
                    EstadoAsistencia estado = EstadoAsistencia.valueOf(datos[3]);
                    String obs = datos.length > 4 ? datos[4].replace(";", ",") : "";

                    Docente docente = buscarDocentePorId(idDocente);
                    if (docente != null) {
                        super.registrarAsistencia(docente, fecha, estado, obs);
                    }
                }
            }
            
        } catch (Exception e) {
            System.out.println("Error al cargar asistencias: " + e.getMessage());
        }
    }

    private void guardarDocentes() {
        try (PrintWriter pw = new PrintWriter(new FileWriter(archivoDocentes))) {
            pw.println("id,nombre,apellido,dni,fechaIngreso");
            for (Docente d : docentes) {
                pw.printf("%d,%s,%s,%s,%s%n", 
                    d.getId(), d.getNombre(), d.getApellido(), d.getDni(), d.getFechaIngreso());
            }
        } catch (Exception e) {
            System.out.println("Error al guardar docentes: " + e.getMessage());
        }
    }

    private void guardarAsistencias() {
        try (PrintWriter pw = new PrintWriter(new FileWriter(archivoAsistencias))) {
            pw.println("idDocente,fecha,estado,observacion");
            for (List<RegistroAsistencia> lista : registros.values()) {
                for (RegistroAsistencia r : lista) {
                    pw.printf("%d,%s,%s,%s%n",
                        r.getDocente().getId(),
                        r.getFecha(),
                        r.getEstado(),
                        r.getObservacion().replace(",", ";"));
                }
            }
        } catch (Exception e) {
            System.out.println("Error al guardar asistencias: " + e.getMessage());
        }
    }

    // ====================== SOBREESCRITURA ======================

    @Override
    public void agregarDocente(Docente docente) {
        super.agregarDocente(docente);
        guardarDocentes();
    }

    @Override
    public void registrarAsistencia(Docente docente, LocalDate fecha, 
                                    EstadoAsistencia estado, String observacion) {
        super.registrarAsistencia(docente, fecha, estado, observacion);
        guardarAsistencias();
    }

    @Override
    public boolean eliminarDocente(int id) {
        boolean eliminado = super.eliminarDocente(id);
        if (eliminado) {
            guardarDocentes();
            guardarAsistencias(); // Limpiar registros del docente eliminado
        }
        return eliminado;
    }

    @Override
    public void verAsistenciaDelDia(LocalDate fecha) {
        System.out.println("\n=== ASISTENCIA DEL DÍA " + fecha + " (ARCHIVO) ===");
        List<RegistroAsistencia> lista = getRegistrosDelDia(fecha);
        if (lista.isEmpty()) {
            System.out.println("No hay registros para este día.");
            return;
        }
        lista.forEach(System.out::println);
    }
}