package registroasistenciadocentes;

public enum EstadoAsistencia {
    PRESENTE,
    AUSENTE,
    JUSTIFICADO
}

