package registroasistenciadocentes;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDate;
import java.util.List;

public class RegistroAsistenciaDocentes {

    private static GestorAsistenciaAbstracta gestor;
    private static JFrame frame;
    private static DefaultTableModel docentesTableModel;

    public static void main(String[] args) {
        System.setProperty("file.encoding", "UTF-8");

        gestor = new GestorAsistenciaArchivo("asistencia");

        SwingUtilities.invokeLater(() -> crearInterfaz());
    }

    private static void crearInterfaz() {
        frame = new JFrame("🏫 Sistema de Asistencia de Docentes");
        frame.setSize(950, 650);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);

        JTabbedPane tabbedPane = new JTabbedPane();

        tabbedPane.addTab("📋 Docentes", crearPanelDocentes());
        tabbedPane.addTab("📝 Registrar Asistencia", crearPanelRegistro());
        tabbedPane.addTab("📅 Asistencia del Día", crearPanelVerAsistencia());
        tabbedPane.addTab("📊 Estadísticas", crearPanelEstadisticas());

        frame.add(tabbedPane);
        frame.setVisible(true);
    }

    // ====================== PANEL DOCENTES ======================
    private static JPanel crearPanelDocentes() {
        JPanel panel = new JPanel(new BorderLayout());
        docentesTableModel = new DefaultTableModel(new String[]{"ID", "Nombre Completo", "DNI", "Fecha Ingreso"}, 0);
        JTable table = new JTable(docentesTableModel);
        JScrollPane scroll = new JScrollPane(table);

        JPanel botones = new JPanel();
        JButton btnAgregar = new JButton("➕ Agregar Docente");
        JButton btnEliminar = new JButton("🗑 Eliminar Docente");
        JButton btnActualizar = new JButton("🔄 Actualizar Lista");

        botones.add(btnAgregar);
        botones.add(btnEliminar);
        botones.add(btnActualizar);

        btnAgregar.addActionListener(e -> agregarDocenteGUI());
        btnEliminar.addActionListener(e -> eliminarDocenteGUI(table));
        btnActualizar.addActionListener(e -> actualizarTablaDocentes());

        panel.add(scroll, BorderLayout.CENTER);
        panel.add(botones, BorderLayout.SOUTH);

        actualizarTablaDocentes();
        return panel;
    }

    private static void actualizarTablaDocentes() {
        docentesTableModel.setRowCount(0);
        for (Docente d : gestor.getDocentes()) {
            docentesTableModel.addRow(new Object[]{
                d.getId(), d.getNombre() + " " + d.getApellido(), d.getDni(), d.getFechaIngreso()
            });
        }
    }

    private static void agregarDocenteGUI() {
        JTextField nombre = new JTextField(15);
        JTextField apellido = new JTextField(15);
        JTextField dni = new JTextField(15);

        Object[] fields = {
            "Nombre:", nombre,
            "Apellido:", apellido,
            "DNI:", dni
        };

        int option = JOptionPane.showConfirmDialog(frame, fields, "Nuevo Docente", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            try {
                gestor.agregarDocente(new Docente(nombre.getText(), apellido.getText(), dni.getText()));
                actualizarTablaDocentes();
                JOptionPane.showMessageDialog(frame, "✅ Docente agregado correctamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(frame, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private static void eliminarDocenteGUI(JTable table) {
        int row = table.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(frame, "Seleccione un docente de la tabla", "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int id = (int) docentesTableModel.getValueAt(row, 0);
        Docente d = gestor.buscarDocentePorId(id);

        int confirm = JOptionPane.showConfirmDialog(frame, 
            "¿Eliminar a " + d.getNombre() + " " + d.getApellido() + "?", 
            "Confirmar Eliminación", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            gestor.eliminarDocente(id);
            actualizarTablaDocentes();
            JOptionPane.showMessageDialog(frame, "✅ Docente eliminado correctamente");
        }
    }

    // ====================== PANEL REGISTRAR ASISTENCIA ======================
    private static JPanel crearPanelRegistro() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(20, 20, 20, 20);

        JButton btnRegistrar = new JButton("📝 Registrar Asistencia");
        btnRegistrar.setFont(new Font("Arial", Font.BOLD, 18));
        btnRegistrar.setPreferredSize(new Dimension(350, 80));

        btnRegistrar.addActionListener(e -> registrarAsistenciaGUI());

        panel.add(btnRegistrar, gbc);
        return panel;
    }

    private static void registrarAsistenciaGUI() {
        String idStr = JOptionPane.showInputDialog(frame, "Ingrese ID del docente:");
        if (idStr == null || idStr.trim().isEmpty()) return;

        try {
            int id = Integer.parseInt(idStr);
            Docente docente = gestor.buscarDocentePorId(id);
            if (docente == null) {
                JOptionPane.showMessageDialog(frame, "❌ Docente no encontrado", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            String[] opciones = {"✅ Presente", "❌ Ausente", "⚠️ Justificado"};
            int choice = JOptionPane.showOptionDialog(frame, 
                "Estado para: " + docente.getNombre() + " " + docente.getApellido(), 
                "Registro de Asistencia", 
                JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, opciones, opciones[0]);

            if (choice == -1) return;

            EstadoAsistencia estado = switch (choice) {
                case 0 -> EstadoAsistencia.PRESENTE;
                case 1 -> EstadoAsistencia.AUSENTE;
                case 2 -> EstadoAsistencia.JUSTIFICADO;
                default -> EstadoAsistencia.PRESENTE;
            };

            String obs = "";
            if (estado != EstadoAsistencia.PRESENTE) {
                obs = JOptionPane.showInputDialog(frame, "Observación (obligatoria):");
                if (obs == null || obs.trim().isEmpty()) obs = "(Sin observación)";
            }

            gestor.registrarAsistencia(docente, LocalDate.now(), estado, obs);
            JOptionPane.showMessageDialog(frame, "✅ Asistencia registrada correctamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(frame, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // ====================== PANEL ASISTENCIA DEL DÍA ======================
    private static JPanel crearPanelVerAsistencia() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        JTextArea area = new JTextArea();
        area.setEditable(false);
        area.setFont(new Font("Monospaced", Font.PLAIN, 14));
        JScrollPane scroll = new JScrollPane(area);

        JButton btnVerHoy = new JButton("📅 Ver Asistencia de Hoy");
        btnVerHoy.addActionListener(e -> verAsistenciaHoyGUI(area));

        panel.add(scroll, BorderLayout.CENTER);
        panel.add(btnVerHoy, BorderLayout.SOUTH);
        return panel;
    }

    private static void verAsistenciaHoyGUI(JTextArea area) {
        area.setText("");
        List<RegistroAsistencia> lista = gestor.getRegistrosDelDia(LocalDate.now());

        if (lista.isEmpty()) {
            area.append("No hay registros de asistencia para hoy.\n");
            return;
        }

        area.append("=== ASISTENCIA DEL DÍA " + LocalDate.now() + " ===\n\n");
        for (RegistroAsistencia r : lista) {
            area.append(r.toString() + "\n");
        }
    }

    // ====================== PANEL ESTADÍSTICAS ======================
    private static JPanel crearPanelEstadisticas() {
        JPanel panel = new JPanel(new GridLayout(2, 1, 15, 15));
        panel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));

        JButton btnGeneral = new JButton("📊 Estadísticas Generales");
        JButton btnPorDocente = new JButton("📈 Porcentaje por Docente");

        btnGeneral.addActionListener(e -> mostrarEstadisticasGeneralesGUI());
        btnPorDocente.addActionListener(e -> mostrarPorcentajeGUI());

        panel.add(btnGeneral);
        panel.add(btnPorDocente);
        return panel;
    }

    private static void mostrarEstadisticasGeneralesGUI() {
        StringBuilder sb = new StringBuilder();
        sb.append("=== ESTADÍSTICAS GENERALES ===\n\n");
        sb.append("Total de Docentes: ").append(gestor.getDocentes().size()).append("\n");
        sb.append("Días con registros: ").append(gestor.getRegistrosDelDia(LocalDate.now()).size() > 0 ? "Sí" : "No").append("\n");

        JOptionPane.showMessageDialog(frame, sb.toString(), "Estadísticas Generales", JOptionPane.INFORMATION_MESSAGE);
    }

    private static void mostrarPorcentajeGUI() {
        String idStr = JOptionPane.showInputDialog(frame, "Ingrese ID del docente:");
        if (idStr == null) return;

        try {
            int id = Integer.parseInt(idStr);
            double porc = gestor.getPorcentajeAsistencia(id);
            Docente d = gestor.buscarDocentePorId(id);

            if (d != null) {
                String msg = String.format("📊 %s %s\n\nPorcentaje de asistencia: %.2f%%", 
                        d.getNombre(), d.getApellido(), porc);
                JOptionPane.showMessageDialog(frame, msg, "Porcentaje", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(frame, "Docente no encontrado");
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(frame, "Error: ID inválido");
        }
    }
}