package registroasistenciadocentes;

import java.time.LocalDate;
import java.util.List;

public interface IGestorAsistencia {

    // ====================== GESTIÓN DE DOCENTES ======================
    void agregarDocente(Docente docente);
    void listarDocentes();
    List<Docente> getDocentes();
    Docente buscarDocentePorId(int id);
    boolean existeDocente(String dni);
    boolean eliminarDocente(int id);

    // ====================== GESTIÓN DE ASISTENCIA ======================
    void registrarAsistencia(Docente docente, LocalDate fecha, 
                           EstadoAsistencia estado, String observacion);
    
    void verAsistenciaDelDia(LocalDate fecha);
    List<RegistroAsistencia> getRegistrosDelDia(LocalDate fecha);
    List<RegistroAsistencia> getRegistrosPorDocente(int docenteId);

    // ====================== ESTADÍSTICAS ======================
    double getPorcentajeAsistencia(int docenteId);
    void mostrarEstadisticasDelDia(LocalDate fecha);
    void mostrarEstadisticasGenerales();
}