package registroasistenciadocentes;

import java.time.LocalDate;

public class RegistroAsistencia {
    private final LocalDate fecha;
    private final Docente docente;
    private final EstadoAsistencia estado;
    private final String observacion;

    public RegistroAsistencia(Docente docente, LocalDate fecha, 
                             EstadoAsistencia estado, String observacion) {
        this.fecha = fecha;
        this.docente = docente;
        this.estado = estado;
        this.observacion = (observacion == null) ? "" : observacion.trim();
    }

    public LocalDate getFecha() { return fecha; }
    public Docente getDocente() { return docente; }
    public EstadoAsistencia getEstado() { return estado; }
    public String getObservacion() { return observacion; }

    @Override
    public String toString() {
        return fecha + " | " + docente + " → " + estado +
               (!observacion.isEmpty() ? " (" + observacion + ")" : "");
    }
}