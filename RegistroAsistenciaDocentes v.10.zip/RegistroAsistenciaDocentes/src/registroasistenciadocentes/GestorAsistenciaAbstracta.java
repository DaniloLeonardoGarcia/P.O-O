package registroasistenciadocentes;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public abstract class GestorAsistenciaAbstracta implements IGestorAsistencia {
    
    protected List<Docente> docentes;
    protected Map<LocalDate, List<RegistroAsistencia>> registros;
    
    public GestorAsistenciaAbstracta() {
        this.docentes = new ArrayList<>();
        this.registros = new HashMap<>();
    }
    
        @Override
    public void agregarDocente(Docente docente) {
        if (docente == null) {
            System.out.println("Error: Docente no válido.");
            return;
        }

        // Validación de DNI único (mejorada)
        if (existeDocente(docente.getDni())) {
            System.out.println("Ya existe un docente registrado con el DNI: " + docente.getDni());
            System.out.println("   No se puede agregar duplicados.");
            return;
        }

        docentes.add(docente);
        System.out.println("Docente agregado correctamente: " + docente);
    }
    
    @Override
    public Docente buscarDocentePorId(int id) {
        return docentes.stream()
                .filter(d -> d.getId() == id)
                .findFirst()
                .orElse(null);
    }
    
    @Override
    public boolean existeDocente(String dni) {
        return docentes.stream().anyMatch(d -> d.getDni().equals(dni));
    }
    
    @Override
    public boolean eliminarDocente(int id) {
        return docentes.removeIf(d -> d.getId() == id);
    }
    
    @Override
    public void listarDocentes() {
        if (docentes.isEmpty()) {
            System.out.println("No hay docentes registrados aún.");
            return;
        }
        System.out.println("\n=== LISTA DE DOCENTES ===");
        docentes.forEach(System.out::println);
    }
    
    @Override
    public List<Docente> getDocentes() {
        return new ArrayList<>(docentes);
    }
    
    @Override
    public void registrarAsistencia(Docente docente, LocalDate fecha, 
                                    EstadoAsistencia estado, String observacion) {
        if (docente == null) {
            System.out.println("Error: Docente no válido");
            return;
        }
        
        RegistroAsistencia registro = new RegistroAsistencia(docente, fecha, estado, observacion);
        registros.putIfAbsent(fecha, new ArrayList<>());
        registros.get(fecha).add(registro);
        
        System.out.println("Asistencia registrada: " + registro);
    }
    
    @Override
    public List<RegistroAsistencia> getRegistrosDelDia(LocalDate fecha) {
        return registros.getOrDefault(fecha, new ArrayList<>());
    }
    
    @Override
    public List<RegistroAsistencia> getRegistrosPorDocente(int docenteId) {
        return registros.values().stream()
                .flatMap(List::stream)
                .filter(r -> r.getDocente().getId() == docenteId)
                .collect(Collectors.toList());
    }
    
    @Override
    public double getPorcentajeAsistencia(int docenteId) {
        List<RegistroAsistencia> regs = getRegistrosPorDocente(docenteId);
        if (regs.isEmpty()) return 0.0;
        
        long presentes = regs.stream()
                .filter(r -> r.getEstado() == EstadoAsistencia.PRESENTE)
                .count();
        
        return Math.round((double) presentes / regs.size() * 100 * 100.0) / 100.0;
    }
    
    @Override
    public void mostrarEstadisticasDelDia(LocalDate fecha) {
        List<RegistroAsistencia> lista = getRegistrosDelDia(fecha);
        if (lista.isEmpty()) {
            System.out.println("No hay registros para el día " + fecha);
            return;
        }
        System.out.println("\n=== ESTADÍSTICAS DEL DÍA " + fecha + " ===");
        System.out.println("Total registros: " + lista.size());
    }
    
    @Override
    public void mostrarEstadisticasGenerales() {
        System.out.println("\n=== ESTADÍSTICAS GENERALES ===");
        System.out.println("Total de docentes: " + docentes.size());
        System.out.println("Días con registros: " + registros.size());
    }
    
    @Override
    public abstract void verAsistenciaDelDia(LocalDate fecha);
}