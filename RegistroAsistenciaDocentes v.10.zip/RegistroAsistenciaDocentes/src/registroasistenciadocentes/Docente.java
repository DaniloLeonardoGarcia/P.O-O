package registroasistenciadocentes;

import java.time.LocalDate;

public class Docente {
    private static int contadorId = 1;
    private final int id;
    private final String nombre;
    private final String apellido;
    private final String dni;
    private final LocalDate fechaIngreso;

    // Constructor normal
    public Docente(String nombre, String apellido, String dni) {
        this(contadorId++, nombre, apellido, dni);
    }

    // Constructor para cargar desde archivo (respeta el ID)
    public Docente(int id, String nombre, String apellido, String dni) {
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre no puede estar vacío");
        }
        if (apellido == null || apellido.trim().isEmpty()) {
            throw new IllegalArgumentException("El apellido no puede estar vacío");
        }
        if (dni == null || dni.trim().isEmpty()) {
            throw new IllegalArgumentException("El DNI no puede estar vacío");
        }

        this.id = id;
        this.nombre = nombre.trim();
        this.apellido = apellido.trim();
        this.dni = dni.trim();
        this.fechaIngreso = LocalDate.now();

        // Actualizar contador para evitar duplicados futuros
        if (id >= contadorId) {
            contadorId = id + 1;
        }
    }

    public int getId() { return id; }
    public String getNombre() { return nombre; }
    public String getApellido() { return apellido; }
    public String getDni() { return dni; }
    public LocalDate getFechaIngreso() { return fechaIngreso; }

    @Override
    public String toString() {
        return String.format("%d - %s %s (%s)", id, nombre, apellido, dni);
    }
}