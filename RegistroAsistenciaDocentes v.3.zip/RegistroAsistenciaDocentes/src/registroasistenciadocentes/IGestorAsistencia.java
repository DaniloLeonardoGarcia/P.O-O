package registroasistenciadocentes;

import java.time.LocalDate;
import java.util.List;

public interface IGestorAsistencia {
    
    void agregarDocente(Docente docente);
    void registrarAsistencia(Docente docente, LocalDate fecha, EstadoAsistencia estado, String observacion);
    void verAsistenciaDelDia(LocalDate fecha);
    void listarDocentes();
    List<Docente> getDocentes();
}
