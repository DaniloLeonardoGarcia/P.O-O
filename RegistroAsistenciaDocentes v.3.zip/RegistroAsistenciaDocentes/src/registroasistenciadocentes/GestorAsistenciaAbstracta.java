package registroasistenciadocentes;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public abstract class GestorAsistenciaAbstracta implements IGestorAsistencia {
    
    protected List<Docente> docentes;
    protected Map<LocalDate, List<RegistroAsistencia>> registros;
    
    public GestorAsistenciaAbstracta() {
        this.docentes = new ArrayList<>();
        this.registros = new HashMap<>();
    }
    
    // Métodos concretos comunes
    @Override
    public void agregarDocente(Docente docente) {
        if (docente != null) {
            docentes.add(docente);
            System.out.println("Docente agregado: " + docente);
        }
    }
    
    @Override
    public void listarDocentes() {
        if (docentes.isEmpty()) {
            System.out.println("No hay docentes registrados aún.");
            return;
        }
        System.out.println("\n=== LISTA DE DOCENTES ===");
        docentes.forEach(System.out::println);
    }
    
    @Override
    public List<Docente> getDocentes() {
        return docentes;
    }
    
    // Método que las subclases pueden sobrescribir
    @Override
    public void registrarAsistencia(Docente docente, LocalDate fecha, 
                                    EstadoAsistencia estado, String observacion) {
        RegistroAsistencia registro = new RegistroAsistencia(docente, fecha, estado, observacion);
        registros.putIfAbsent(fecha, new ArrayList<>());
        registros.get(fecha).add(registro);
        System.out.println("Asistencia registrada: " + registro);
    }
    
    @Override
    public abstract void verAsistenciaDelDia(LocalDate fecha);
}