package registroasistenciadocentes;

import java.time.LocalDate;
import java.util.List;

public class GestorAsistenciaArchivo extends GestorAsistenciaAbstracta {
    
    private String nombreArchivo;
    
    public GestorAsistenciaArchivo(String nombreArchivo) {
        super();
        this.nombreArchivo = nombreArchivo;
        System.out.println("Gestor de Asistencia en ARCHIVO iniciado: " + nombreArchivo);
    }
    
    @Override
    public void verAsistenciaDelDia(LocalDate fecha) {
        System.out.println("\n=== ASISTENCIA DEL DÍA " + fecha + " (ARCHIVO: " + nombreArchivo + ") ===");
        System.out.println("(Simulación) Leyendo datos desde archivo...");
        
        // Por ahora reutilizamos la lógica de memoria
        List<RegistroAsistencia> lista = registros.get(fecha);
        
        if (lista == null || lista.isEmpty()) {
            System.out.println("No hay registros para este día en el archivo.");
            return;
        }
        lista.forEach(System.out::println);
    }
    
    // Puedes sobrescribir más métodos en el futuro para realmente guardar en archivo
    @Override
    public void registrarAsistencia(Docente docente, LocalDate fecha, 
                                    EstadoAsistencia estado, String observacion) {
        super.registrarAsistencia(docente, fecha, estado, observacion);
        System.out.println("💾 Datos guardados en archivo: " + nombreArchivo);
    }
}