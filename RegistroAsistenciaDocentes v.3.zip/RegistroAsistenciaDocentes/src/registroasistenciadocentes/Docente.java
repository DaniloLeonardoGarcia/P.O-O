/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package registroasistenciadocentes;
import java.time.LocalDate;
public class Docente {
    private static int contadorId= 1;
    private int id;
    private String nombre;
    private String apellido;
    private String dni;
    private LocalDate fechaIngreso;
    
    public Docente(String nombre, String apellido, String dni){
        this.id=contadorId++;
        this.nombre=nombre;
        this.apellido=apellido;
        this.dni=dni;
        this.fechaIngreso=LocalDate.now();
    }
    public int getId() {return id;}
    public String getNombre() {return nombre;}
    public String getApellido() {return apellido;}
    public String getDni() {return dni;}
    public LocalDate getFechaIngreso() {return fechaIngreso;}
    
    @Override
    public String toString(){
        return id + "-" + nombre + "-" + apellido + " (" + dni + ")";
    }
}
