package registroasistenciadocentes;

import java.sql.*;
import java.time.LocalDate;
import java.util.*;

public class GestorAsistenciaSQL extends GestorAsistenciaAbstracta<Docente> {

    private static final String URL = 
        "jdbc:sqlserver://localhost\\SQLEXPRESS;databaseName=RegistroAsistenciaDocentes;" +
        "integratedSecurity=true;encrypt=false;trustServerCertificate=true";

    public GestorAsistenciaSQL() {
        super();
        System.out.println("Gestor SQL Server iniciado");
        cargarDatos();
    }

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL);
    }

    private void cargarDatos() {
        cargarDocentes();
    }

    private void cargarDocentes() {
        String sql = "SELECT id, nombre, apellido, dni, fechaIngreso FROM Docentes";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Docente d = new Docente(
                    rs.getInt("id"),
                    rs.getString("nombre"),
                    rs.getString("apellido"),
                    rs.getString("dni"),
                    rs.getDate("fechaIngreso").toLocalDate()
                );
                docentes.add(d);
            }
            System.out.println("Docentes cargados: " + docentes.size());
        } catch (Exception e) {
            System.out.println("Error cargando docentes: " + e.getMessage());
        }
    }

    @Override
    public void agregarDocente(Docente docente) {
        super.agregarDocente(docente);
        String sql = "INSERT INTO Docentes (nombre, apellido, dni, fechaIngreso) VALUES (?, ?, ?, ?)";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, docente.getNombre());
            ps.setString(2, docente.getApellido());
            ps.setString(3, docente.getDni());
            ps.setDate(4, java.sql.Date.valueOf(docente.getFechaIngreso()));
            ps.executeUpdate();
            System.out.println("Docente guardado en BD");
        } catch (Exception e) {
            System.out.println("Error guardando docente: " + e.getMessage());
        }
    }

    @Override
    public void registrarAsistencia(Docente docente, LocalDate fecha, EstadoAsistencia estado, String observacion) {
        super.registrarAsistencia(docente, fecha, estado, observacion);
        
        String sql = "INSERT INTO Asistencias (idDocente, fecha, estado, observacion) VALUES (?, ?, ?, ?)";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, docente.getId());
            ps.setDate(2, java.sql.Date.valueOf(fecha));
            ps.setString(3, estado.name());
            ps.setString(4, observacion != null ? observacion : "");
            ps.executeUpdate();
            System.out.println("Asistencia guardada en BD");
        } catch (Exception e) {
            System.out.println("Error registrando asistencia: " + e.getMessage());
        }
    }

    @Override
    public boolean eliminarDocente(int id) {
        boolean eliminado = super.eliminarDocente(id);
        if (eliminado) {
            try (Connection conn = getConnection()) {
                try (PreparedStatement ps = conn.prepareStatement("DELETE FROM Asistencias WHERE idDocente = ?")) {
                    ps.setInt(1, id); ps.executeUpdate();
                }
                try (PreparedStatement ps = conn.prepareStatement("DELETE FROM Docentes WHERE id = ?")) {
                    ps.setInt(1, id); ps.executeUpdate();
                }
                System.out.println("Docente eliminado de BD");
            } catch (Exception e) {
                System.out.println("Error eliminando docente: " + e.getMessage());
            }
        }
        return eliminado;
    }

    @Override
    public void verAsistenciaDelDia(LocalDate fecha) {
        System.out.println("\n=== ASISTENCIA DEL DÍA " + fecha + " (SQL Server) ===");
        List<RegistroAsistencia> registros = getRegistrosDelDia(fecha);
        registros.forEach(System.out::println);
        if (registros.isEmpty()) {
            System.out.println("No hay registros para este día.");
        }
    }
}