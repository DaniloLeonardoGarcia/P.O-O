package registroasistenciadocentes;

public interface EstrategiaEstadisticas {
    String calcular(GestorAsistenciaAbstracta<Docente> gestor);
}

class EstadisticasGeneralesStrategy implements EstrategiaEstadisticas {
    @Override
    public String calcular(GestorAsistenciaAbstracta<Docente> gestor) {
        long totalPresentes = gestor.getDocentes().stream()
            .flatMap(d -> gestor.getRegistrosPorDocente(d.getId()).stream())
            .filter(r -> r.getEstado() == EstadoAsistencia.PRESENTE)
            .count();

        long totalRegistros = gestor.getDocentes().stream()
            .mapToInt(d -> gestor.getRegistrosPorDocente(d.getId()).size())
            .sum();

        return """
            === ESTADÍSTICAS GENERALES ===
            
            Total de Docentes: %d
            Días con registros: %d
            Total de registros: %d
            Asistencias presentes: %d
            """.formatted(
                gestor.getDocentes().size(),
                gestor.getTotalDiasRegistrados(),
                totalRegistros,
                totalPresentes
            );
    }
}