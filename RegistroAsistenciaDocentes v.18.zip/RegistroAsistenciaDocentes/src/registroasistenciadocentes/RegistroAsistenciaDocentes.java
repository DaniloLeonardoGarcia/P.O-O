package registroasistenciadocentes;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDate;

public class RegistroAsistenciaDocentes {

    private static final GestorAsistenciaAbstracta<Docente> gestor = new GestorAsistenciaSQL();
    private static JFrame frame;
    private static DefaultTableModel tableModel;

    public static void main(String[] args) {
        System.setProperty("file.encoding", "UTF-8");
        SwingUtilities.invokeLater(RegistroAsistenciaDocentes::crearInterfaz);
    }

    private static void crearInterfaz() {
        frame = new JFrame("Sistema de Asistencia de Docentes");
        frame.setSize(1000, 700);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);

        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("Docentes", crearPanelDocentes());
        tabs.addTab("Registrar", crearPanelRegistro());
        tabs.addTab("Hoy", crearPanelHoy());
        tabs.addTab("Estadísticas", crearPanelEstadisticas());

        frame.add(tabs);
        frame.setVisible(true);
    }

    private static JPanel crearPanelDocentes() {
        tableModel = new DefaultTableModel(new String[]{"ID", "Nombre", "DNI", "Ingreso"}, 0);
        JTable table = new JTable(tableModel);
        JScrollPane scroll = new JScrollPane(table);

        JPanel botones = new JPanel();
        JButton add = new JButton("Agregar");
        JButton del = new JButton("Eliminar");
        JButton ref = new JButton("Actualizar");

        add.addActionListener(e -> agregarDocente());
        del.addActionListener(e -> eliminarDocente(table));
        ref.addActionListener(e -> actualizarTabla());

        botones.add(add);
        botones.add(del);
        botones.add(ref);

        JPanel panel = new JPanel(new BorderLayout());
        panel.add(scroll, BorderLayout.CENTER);
        panel.add(botones, BorderLayout.SOUTH);
        actualizarTabla();
        return panel;
    }

    private static void actualizarTabla() {
        tableModel.setRowCount(0);
        gestor.getDocentes().forEach(d ->
            tableModel.addRow(new Object[]{
                d.getId(), 
                d.getNombre() + " " + d.getApellido(), 
                d.getDni(), 
                d.getFechaIngreso()
            })
        );
    }

    private static void agregarDocente() {
        JTextField n = new JTextField(), a = new JTextField(), d = new JTextField();
        Object[] msg = {"Nombre:", n, "Apellido:", a, "DNI:", d};

        if (JOptionPane.showConfirmDialog(frame, msg, "Nuevo Docente", JOptionPane.OK_CANCEL_OPTION) == JOptionPane.OK_OPTION) {
            try {
                gestor.agregarDocente(new Docente(n.getText(), a.getText(), d.getText()));
                actualizarTabla();
                JOptionPane.showMessageDialog(frame, "Docente agregado");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(frame, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private static void eliminarDocente(JTable table) {
        int row = table.getSelectedRow();
        if (row == -1) return;

        int id = (int) tableModel.getValueAt(row, 0);
        Docente doc = gestor.buscarDocentePorId(id);

        if (JOptionPane.showConfirmDialog(frame, "¿Eliminar a " + doc + "?", "Confirmar", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            gestor.eliminarDocente(id);
            actualizarTabla();
        }
    }

    private static JPanel crearPanelRegistro() {
        JButton btn = new JButton("Registrar Asistencia");
        btn.setFont(new Font("Arial", Font.BOLD, 18));
        btn.setPreferredSize(new Dimension(400, 90));
        btn.addActionListener(e -> registrarAsistencia());

        JPanel p = new JPanel(new GridBagLayout());
        p.add(btn);
        return p;
    }

    private static void registrarAsistencia() {
        String idStr = JOptionPane.showInputDialog(frame, "Ingrese ID del docente:");
        if (idStr == null || idStr.trim().isEmpty()) return;

        try {
            Docente d = gestor.buscarDocentePorId(Integer.parseInt(idStr));
            if (d == null) throw new Exception("Docente no encontrado");

            String[] opciones = {"Presente", "Ausente", "Justificado"};
            int choice = JOptionPane.showOptionDialog(frame, "Estado para: " + d, "Registro", 
                    JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, opciones, opciones[0]);

            if (choice == -1) return;

            EstadoAsistencia estado = switch (choice) {
                case 1 -> EstadoAsistencia.AUSENTE;
                case 2 -> EstadoAsistencia.JUSTIFICADO;
                default -> EstadoAsistencia.PRESENTE;
            };

            String obs = (estado != EstadoAsistencia.PRESENTE) ? 
                    JOptionPane.showInputDialog(frame, "Observación:") : "";

            gestor.registrarAsistencia(d, LocalDate.now(), estado, obs);
            JOptionPane.showMessageDialog(frame, "Asistencia registrada correctamente");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(frame, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private static JPanel crearPanelHoy() {
        JTextArea area = new JTextArea();
        area.setEditable(false);
        area.setFont(new Font("Monospaced", Font.PLAIN, 14));

        JButton btn = new JButton("Ver Asistencia de Hoy");
        btn.addActionListener(e -> verHoy(area));

        JPanel p = new JPanel(new BorderLayout(10, 10));
        p.add(new JScrollPane(area), BorderLayout.CENTER);
        p.add(btn, BorderLayout.SOUTH);
        return p;
    }

    private static void verHoy(JTextArea area) {
        area.setText("=== ASISTENCIA DEL DÍA " + LocalDate.now() + " ===\n\n");
        gestor.getRegistrosDelDia(LocalDate.now()).forEach(r -> area.append(r + "\n"));
    }

    private static JPanel crearPanelEstadisticas() {
        JPanel p = new JPanel(new GridLayout(2, 1, 15, 15));
        p.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));

        JButton gen = new JButton("Estadísticas Generales");
        JButton porc = new JButton("Porcentaje por Docente");

        gen.addActionListener(e -> estadisticasGenerales());
        porc.addActionListener(e -> porcentajePorDocente());

        p.add(gen);
        p.add(porc);
        return p;
    }

    private static void estadisticasGenerales() {
        long totalPresentes = gestor.getDocentes().stream()
            .flatMap(d -> gestor.getRegistrosPorDocente(d.getId()).stream())
            .filter(r -> r.getEstado() == EstadoAsistencia.PRESENTE)
            .count();

        long totalRegistros = gestor.getDocentes().stream()
            .mapToInt(d -> gestor.getRegistrosPorDocente(d.getId()).size())
            .sum();

        String msg = """
            === ESTADÍSTICAS GENERALES ===
            
            Total de Docentes: %d
            Días con registros: %d
            Total de registros: %d
            Asistencias presentes: %d
            """.formatted(
                gestor.getDocentes().size(),
                gestor.getTotalDiasRegistrados(),
                totalRegistros,
                totalPresentes
            );

        JOptionPane.showMessageDialog(frame, msg, "Estadísticas", JOptionPane.INFORMATION_MESSAGE);
    }

    private static void porcentajePorDocente() {
        String idStr = JOptionPane.showInputDialog(frame, "ID del docente:");
        if (idStr == null || idStr.trim().isEmpty()) return;

        try {
            int id = Integer.parseInt(idStr);
            Docente d = gestor.buscarDocentePorId(id);
            if (d == null) throw new Exception("Docente no encontrado");

            double porc = gestor.getPorcentajeAsistencia(id);
            JOptionPane.showMessageDialog(frame, 
                "%s\nPorcentaje de asistencia: %.2f%%".formatted(d, porc));
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(frame, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}