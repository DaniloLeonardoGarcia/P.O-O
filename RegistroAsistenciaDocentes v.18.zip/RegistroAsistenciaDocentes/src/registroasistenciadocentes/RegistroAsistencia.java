package registroasistenciadocentes;

import java.time.LocalDate;

public class RegistroAsistencia {

    private Docente docente;
    private LocalDate fecha;
    private EstadoAsistencia estado;
    private String observacion;

    public RegistroAsistencia(
            Docente docente,
            LocalDate fecha,
            EstadoAsistencia estado,
            String observacion) {

        this.docente = docente;
        this.fecha = fecha;
        this.estado = estado;
        this.observacion = observacion;
    }

    public Docente getDocente() {
        return docente;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public EstadoAsistencia getEstado() {
        return estado;
    }

    public String getObservacion() {
        return observacion;
    }

    @Override
    public String toString() {
        return fecha + " - "
                + docente.getNombre()
                + " - "
                + estado;
    }
}