package registroasistenciadocentes;

import java.time.LocalDate;
import java.util.List;

public interface IGestorAsistencia {

    void agregarDocente(Docente docente);
    boolean eliminarDocente(int id);
    boolean existeDocente(String dni);
    Docente buscarDocentePorId(int id);
    List<Docente> getDocentes();
    void registrarAsistencia(Docente docente, LocalDate fecha, EstadoAsistencia estado, String observacion);
    List<RegistroAsistencia> getRegistrosDelDia(LocalDate fecha);
    List<RegistroAsistencia> getRegistrosPorDocente(int docenteId);
    double getPorcentajeAsistencia(int docenteId);
    void verAsistenciaDelDia(LocalDate fecha);
    int getTotalDiasRegistrados();
}