package registroasistenciadocentes;

import java.time.LocalDate;

public class Docente {

    private static int contadorId = 1;

    private final int id;
    private final String nombre;
    private final String apellido;
    private final String dni;
    private final LocalDate fechaIngreso;

    public Docente(String nombre, String apellido, String dni) {
        validar(nombre, apellido, dni);
        this.id = contadorId++;
        this.nombre = nombre.trim();
        this.apellido = apellido.trim();
        this.dni = dni.trim();
        this.fechaIngreso = LocalDate.now();
    }

    public Docente(int id, String nombre, String apellido, String dni, LocalDate fechaIngreso) {
        validar(nombre, apellido, dni);
        this.id = id;
        this.nombre = nombre.trim();
        this.apellido = apellido.trim();
        this.dni = dni.trim();
        this.fechaIngreso = fechaIngreso;

        if (id >= contadorId) contadorId = id + 1;
    }

    private void validar(String nombre, String apellido, String dni) {
        if (nombre == null || nombre.trim().isEmpty())
            throw new IllegalArgumentException("Nombre inválido");
        if (apellido == null || apellido.trim().isEmpty())
            throw new IllegalArgumentException("Apellido inválido");
        if (dni == null || !dni.matches("\\d{8}"))
            throw new IllegalArgumentException("El DNI debe contener exactamente 8 dígitos");
    }

    public int getId() { return id; }
    public String getNombre() { return nombre; }
    public String getApellido() { return apellido; }
    public String getDni() { return dni; }
    public LocalDate getFechaIngreso() { return fechaIngreso; }

    @Override
    public String toString() {
        return nombre + " " + apellido;
    }
}