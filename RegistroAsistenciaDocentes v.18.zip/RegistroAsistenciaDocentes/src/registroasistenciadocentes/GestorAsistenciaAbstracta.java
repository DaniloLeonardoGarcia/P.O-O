package registroasistenciadocentes;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

public abstract class GestorAsistenciaAbstracta<T extends Docente> implements IGestorAsistencia {

    protected final List<T> docentes = new ArrayList<>();
    protected final Map<Integer, List<RegistroAsistencia>> asistencias = new HashMap<>();

    public GestorAsistenciaAbstracta() {}

    @Override
    public void agregarDocente(Docente docente) {
        if (existeDocente(docente.getDni())) {
            throw new IllegalArgumentException("Ya existe un docente con DNI: " + docente.getDni());
        }
        docentes.add((T) docente); // Cast seguro porque T extends Docente
    }

    @Override
    public boolean eliminarDocente(int id) {
        boolean removido = docentes.removeIf(d -> d.getId() == id);
        if (removido) asistencias.remove(id);
        return removido;
    }

    @Override
    public boolean existeDocente(String dni) {
        return docentes.stream().anyMatch(d -> d.getDni().equals(dni));
    }

    @Override
    public Docente buscarDocentePorId(int id) {
        return docentes.stream()
                .filter(d -> d.getId() == id)
                .findFirst()
                .orElse(null);
    }

    @Override
    public List<Docente> getDocentes() {
        return new ArrayList<>(docentes);
    }

    @Override
    public void registrarAsistencia(Docente docente, LocalDate fecha, EstadoAsistencia estado, String observacion) {
        asistencias.computeIfAbsent(docente.getId(), k -> new ArrayList<>())
                .add(new RegistroAsistencia(docente, fecha, estado, observacion));
    }

    @Override
    public List<RegistroAsistencia> getRegistrosDelDia(LocalDate fecha) {
        return asistencias.values().stream()
                .flatMap(List::stream)
                .filter(r -> r.getFecha().equals(fecha))
                .collect(Collectors.toList());
    }

    @Override
    public List<RegistroAsistencia> getRegistrosPorDocente(int docenteId) {
        return asistencias.getOrDefault(docenteId, Collections.emptyList());
    }

    @Override
    public double getPorcentajeAsistencia(int docenteId) {
        List<RegistroAsistencia> registros = getRegistrosPorDocente(docenteId);
        if (registros.isEmpty()) return 0.0;

        long presentes = registros.stream()
                .filter(r -> r.getEstado() == EstadoAsistencia.PRESENTE)
                .count();

        return (presentes * 100.0) / registros.size();
    }

    @Override
    public int getTotalDiasRegistrados() {
        return asistencias.values().stream()
                .flatMap(List::stream)
                .map(RegistroAsistencia::getFecha)
                .distinct()
                .collect(Collectors.toSet())
                .size();
    }
}