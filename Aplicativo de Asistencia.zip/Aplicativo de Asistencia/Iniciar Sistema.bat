@echo off
title Asistencia Docentes
start /B javaw -jar "RegistroAsistenciaDocentes.jar"