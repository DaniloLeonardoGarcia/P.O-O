package registroasistenciadocentes;

import java.time.LocalDate;
import java.util.List;

public class GestorAsistenciaMemoria extends GestorAsistenciaAbstracta {
    
    public GestorAsistenciaMemoria() {
        super();
        System.out.println("✅ Gestor de Asistencia en MEMORIA iniciado.");
    }
    
    @Override
    public void verAsistenciaDelDia(LocalDate fecha) {
        List<RegistroAsistencia> lista = registros.get(fecha);
        
        System.out.println("\n=== ASISTENCIA DEL DÍA " + fecha + " (MEMORIA) ===");
        
        if (lista == null || lista.isEmpty()) {
            System.out.println("No hay registros para este día.");
            return;
        }
        lista.forEach(System.out::println);
    }
}